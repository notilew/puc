import React from 'react'
import ReactDOM from 'react-dom'
import './img/favicon.ico'

ReactDOM.render(
    <h1>Desenvolvimento Front-end Avançado</h1>,
    document.querySelector("#main")
)
