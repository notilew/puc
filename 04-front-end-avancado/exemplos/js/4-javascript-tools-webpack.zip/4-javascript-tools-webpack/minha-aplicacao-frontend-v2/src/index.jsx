import React from 'react'
import ReactDOM from 'react-dom'

ReactDOM.render(
    <h1>Desenvolvimento Front-end Avançado</h1>,
    document.querySelector("#main")
)
