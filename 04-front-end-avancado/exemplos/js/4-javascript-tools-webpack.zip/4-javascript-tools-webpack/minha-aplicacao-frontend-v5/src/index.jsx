import React from 'react'
import ReactDOM from 'react-dom'
import './img/favicon.ico'
import './css/index.css'

ReactDOM.render(
    <h1>Desenvolvimento Front-end Avançado</h1>,
    document.querySelector("#main")
)
