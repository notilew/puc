// Extraído e adaptado de "ECMAScript 6 — New Features: Overview & Comparison"

// lib/math.js
const pi = 3.141593
const e = 2.71828182846
const sum = (x, y) => (x + y)
const exp = x => Math.exp(x)

export {pi, e, exp}
export default sum


// outroArquivo.js
import { exp, pi } from "lib/math"
console.log("e^{π} = " + exp(pi))
