// Extraído de OSMANI, Addy. 2017. Learning JavaScript Design Patterns.
var myRevealingModule = (function() {
  var privateVar = "Ben Cherry",
    publicVar = "Hey there!";

  function privateFunction() {
    console.log("Name:" + privateVar);
  }

  function publicSetName(strName) {
    privateVar = strName;
  }

  function publicGetName() {
    privateFunction();
  }

  // Revelar ponteiros públicos para funções e propriedades privadas
  return {
    setName: publicSetName,
    greeting: publicVar,
    getName: publicGetName
  };
})();

myRevealingModule.setName("Paul Kinlan");
