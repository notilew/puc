// Extraído e adaptado da documentação do Require.js

// Chama a função define() com um array de dependências e uma função factory
define(['dep1', 'dep2'], function (dep1, dep2) {

    // Define o valor do módulo retornando um valor
    return function () {};
});

// Ou em caso de muitas dependências, para facilitar a legibilidade:
define(function (require) {
    var dependency1 = require('dependency1'),
        dependency2 = require('dependency2');

    return function () {};
});
