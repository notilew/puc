// Extraído e adaptado da documentação Node.js > Modules
// Para esse código abaixo funcionar, é necessário ter o node
// instalado, manter o arquivo circle.js e main.js na mesma pasta
// e executar o arquivo main.js. Ex: $ node main.js

// Em um arquivo chamado "circle.js" (isso é, um módulo CommonJS)
const { PI } = Math;

exports.area = (r) => PI * r ** 2;

exports.circumference = (r) => 2 * PI * r;


// Em outro arquivo qualquer, por exemplo, "main.js"
const circle = require('./circle.js');
console.log( `A área do círculo de raio 4 é ${circle.area(4)}`);
