// E aqui está um exemplo resumido para criar a promise:
const promise = new Promise(function(resolve, reject) {
    // Dentro do "executor" você faz alguma coisa,
    // provavelmente alguma assíncrona (mas não necessariamente),
    let acaoFuncionou = true;
    // então...
  
    // Se tudo passou bem com código acima
    if (acaoFuncionou) {
        resolve("Essa coisa funcionou!");
    }
    else {
        reject(Error("Essa coisa falhou"));
    }
});

// E um exemplo resumido para criar usar a promise:
promise.then(function(result) {
    console.log(result); // "Essa coisa funcionou!"
}, function(err) {
    console.log(err); // Error: "Essa coisa falhou"
});
