// Código extraído e adaptado de Felipe N. Moura
// Felipe Nascimento de Moura <felipenmoura@gmail.com>
// Código original em:
// https://braziljs.org/blog/async-await-js-assincronamente-sincrono/

// Deixei o usuário do @felipenmoura (autor do código),
// mas pode testar com o seu usuário do github, se quiser ;)
var user = 'felipenmoura';

async function getGitHubRepo (user) {
    const userName = user;
    const url = 'https://api.github.com/users';
    const reposResponse = await fetch(`${url}/${userName}/repos`);
    const userRepos = await reposResponse.json();
    console.log(userRepos)
}

// Invoca função assíncrona (sempre retorna uma Promise)
var gitHubRepoPromise = getGitHubRepo(user);

// Chamada síncrona. Logo, será executada ANTES da conclusão de getGitHubRepo()
console.log(
    `Executado de forma síncrona após chamada a função getGitHubRepo(),
     mas ANTES de sua conclusão`
);

// Chamada assíncrona. Logo, será executada como uma APÓS a
// promise retornada por getGitHubRepo() ser resolvida.
gitHubRepoPromise.then(() => {
    console.log(
        `Executado de forma assínrona APÓS a função
         getGitHubRepo() ser finalizada`
    );
})
