// Exemplo extraído e adaptado de MDN

// Versão com promises encadeadas
function getProcessedData(url) {
  return downloadData(url) // Retorna uma promise
    .catch(e => {
      return downloadFallbackData(url)  // Retorna uma promise
    })
    .then(v => {
      return processDataInWorker(v); // Retorna uma promise
    });
}

// Versão com async functions
async function getProcessedData(url) {
    let v;
    try {
      v = await downloadData(url);
    } catch(e) {
      v = await downloadFallbackData(url);
    }
    return processDataInWorker(v);
  }
