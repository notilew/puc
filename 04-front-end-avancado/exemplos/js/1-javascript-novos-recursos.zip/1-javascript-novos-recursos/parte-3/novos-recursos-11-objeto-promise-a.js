// Método para recuperar meus saldos bancários do backend.
// Esse método retorna um objeto do tipo "Promise".
var balances = get('balances.json');

// Para usar esse objeto Promise é necessário usar a função "then" para atribuir callbacks:
// 1) a primeira é executado em caso de sucesso
// 2) e a segunda em caso de erro
balances.then(function (response) {
    // requisição assícrona (ajax) executada com sucesso
    // meus saldos bancários retornados ok e posso usá-los
    window.localStorage.setItem('balances', response.data.stringify());
}, function(error) {
    // requisição assícrona (ajax) falhou
    console.log('Recurso não encontrado!');
});
