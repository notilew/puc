// Exemplo extraído e adaptado de MDN

fetch('https://example.com/balances.json')
  .then(function(response) {
    return response.json();
  })
  .then(function(myJson) {
    console.log(JSON.stringify(myJson));
  });