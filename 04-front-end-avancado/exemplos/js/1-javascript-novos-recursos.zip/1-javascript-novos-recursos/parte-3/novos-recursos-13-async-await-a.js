// Sintaxe básica para a declaração de uma função assíncrona
async function nome([parametro[, parametro[, ... parametro]]]) {
    // Sentenças
 
    // Sintaxe básica do operador await
    [rv] = await expressao;
 
    // Sentenças
}
 