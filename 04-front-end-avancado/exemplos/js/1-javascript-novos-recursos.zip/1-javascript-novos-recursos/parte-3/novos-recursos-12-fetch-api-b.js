// Exemplo extraído e adaptado de MDN
var myImage = document.querySelector('img');

var myHeaders = new Headers();
myHeaders.append('Content-Type', 'image/jpeg');

var myInit = {
    method: 'GET', headers: myHeaders,
    mode: 'cors', cache: 'default'
};

var myRequest = new Request('flowers.jpg');

fetch(myRequest, myInit)
  .then(function(response) {
    if (!response.ok) {
      throw new Error("HTTP error, status = " + response.status);
    }
    return response.blob();
  })
  .then(function(blob) {
    var objectURL = URL.createObjectURL(blob);
    myImage.src = objectURL;
  })
  .catch(function(error) {
    // Trata erro
  });