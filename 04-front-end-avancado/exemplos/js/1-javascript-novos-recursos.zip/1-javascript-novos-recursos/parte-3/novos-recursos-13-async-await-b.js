// Código extraído e adaptado de Felipe N. Moura
// Felipe Nascimento de Moura <felipenmoura@gmail.com>
// Código original em:
// https://braziljs.org/blog/async-await-js-assincronamente-sincrono/

// Deixei o usuário do @felipenmoura (autor do código),
// mas pode testar com o seu usuário do github, se quiser ;)
var user = 'felipenmoura';

async function getGitHubRepo (user) {
    const userName = user;
    const url = 'https://api.github.com/users';
    const reposResponse = await fetch(`${url}/${userName}/repos`);
    const userRepos = await reposResponse.json();
    console.log(userRepos)
}

// Invoca função assíncrona
getGitHubRepo(user);
