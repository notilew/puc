// Implementação do método para recuperar meus saldos bancários do backend.
// Esse método retorna um objeto do tipo "Promise".
function get(url) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", url);
    xhr.onload = () => {
      if (xhr.status == 200) {
        resolve(xhr.response)
      } else {
        reject(Error(xhr.statusText))
      }
    }
    xhr.send();
  });
}