// Sintaxe básica criar uma promise:
const promise = new Promise(executor);

// Sendo que o parâmetro "executor" é uma função que recebe dois parâmetros:
const promise = new Promise(
    function(resolve, reject) { /* código */ }
);


// Sintaxe básica para se usar uma promise:
promise.then(
    function(result) { /* callback de sucesso */ },
    function(err) { /* callback de erro */ }
);
