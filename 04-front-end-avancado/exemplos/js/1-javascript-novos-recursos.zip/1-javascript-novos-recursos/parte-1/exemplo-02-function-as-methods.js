/**
 * Pego o nome do álbum
 */
Album.prototype.getName = function() {
    return this.name;
};

/**
 * Pega a coleção de fotos
 */
Album.prototype.getPhotos = function() {
    return this.photos;
};

/**
 * Adciona uma nova foto ao album
 */
Album.prototype.addPhoto = function(url) {
    this.photos.push(url);
};