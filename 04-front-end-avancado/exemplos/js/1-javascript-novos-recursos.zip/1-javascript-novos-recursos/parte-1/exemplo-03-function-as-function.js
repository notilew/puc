function square(number) {
    return number * number;
}

square(4); // output: 16