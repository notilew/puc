// Exemplos extraídos e adaptados de MDN
function testLetAndVar() {
    var a = 5;
    var b = 10;

    if (a === 5) {
        let a = 4; // O escopo é dentro do bloco if
        var b = 1; // O escopo é dentro da função

        console.log(a);  // 4
        console.log(b);  // 1
    } 

    console.log(a); // 5
    console.log(b); // 1
}

testLetAndVar(); // 4, 1, 5, 1

// Uncaught ReferenceError: a is not defined
console.log(a);


// define IDADE como uma constante com valor 33
const IDADE = 33;

// Uncaught TypeError: Assignment to constant variable.
IDADE = 34;