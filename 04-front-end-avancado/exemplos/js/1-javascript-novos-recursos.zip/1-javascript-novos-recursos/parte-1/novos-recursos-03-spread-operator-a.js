// Exemplo extraído e adaptado de MDN
// Sintaxe básica

// Para chamada de funções:
salvar(...objetoIteravel);

// Para arrays literais ou strings
[...objetoIteravel, '4', 'five', 6];

// Para objetos literais (incluído no ES2018)
let objetoClone = { ...objeto };
