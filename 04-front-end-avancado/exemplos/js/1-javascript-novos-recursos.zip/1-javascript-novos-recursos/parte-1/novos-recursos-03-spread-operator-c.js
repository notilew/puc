// Define alguns arrays literais
var cafeDaManha = ['pão integral', 'suco de limão', 'queijo', 'ovos'];
var salada = ['alface', 'rúcula', 'agrião', 'tomate'];

// Cria novos arrays utilizando outros arrays já existentes
var almoco = ['arroz', 'feijão', 'bife', ...salada];
var janta = ['bife de frango', ...salada];

// Cria mais array concanentando outros já existentes
var refeicoes = [...cafeDaManha, ...almoco, ...janta];
// ["pão integral", "suco de limão", "queijo", "ovos", "arroz",
//  "feijão", "bife", "alface", "rúcula", "agrião", "tomate",
//  "bife de frango", "alface", "rúcula", "agrião", "tomate"]
