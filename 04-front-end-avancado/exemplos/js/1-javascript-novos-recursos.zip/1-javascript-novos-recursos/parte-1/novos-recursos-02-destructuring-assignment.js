// Destructuring assingment com array
const person = ['Renato', '33', 'Desenvolvimento Front-end'];

let [name, age, course] = person;

console.log(name);   // Renato
console.log(age);    // 33
console.log(course); // Desenvolvimento Front-end

// Destructuring assingment com objetos
const person = {name: 'Renato', age: '33', course: 'Desenvolvimento Front-end'};

let {age, course, name} = person; // Elementos fora de ordem

console.log(name);   // Renato
console.log(age);    // 33
console.log(course); // Desenvolvimento Front-end
