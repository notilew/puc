// Função com 3 parâmetros
function salvar(nome, nota, disciplina) {
    console.log(nome); // Pedro
    console.log(nota); // 25
    console.log(disciplina); // Front-end avançado
}

var arr = ['Pedro', 25, 'Front-end avançado'];

// Invoca a função usando o operador spread
salvar(...arr);
