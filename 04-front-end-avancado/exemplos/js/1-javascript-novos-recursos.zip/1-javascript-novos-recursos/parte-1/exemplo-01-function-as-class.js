/**
 * Classe Album
 */
function Album(name) {
    this.id = undefined;
    this.name = name;
    this.photos = new Array();
}

// Criando uma nova instância de Album
const albumModel = new Album('Fotos da viagem de final de ano');

// Acessando propriedade
albumModel.name;
// Output: Fotos da viagem de final de ano

