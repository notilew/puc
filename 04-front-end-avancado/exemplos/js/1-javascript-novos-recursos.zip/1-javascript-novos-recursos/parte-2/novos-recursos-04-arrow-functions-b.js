// Exemplo extraído e adaptado de MDN
var elementos = ["Hidrogênio", "Hélio", "Lítio", "Berílio"];

elementos.map(function(element) {
  return element.length;
}); // esta sentença retorna o array: [10, 5, 5, 7]

// A função regular acima pode ser escrita como a arrow function abaixo
elementos.map(element => {
  return element.length;
}); // [10, 5, 5, 7]

// Quando só existe um parâmetro, podemos remover os parênteses envolvendo os parâmetros
elementos.map(element => {
  return element.length;
}); // [10, 5, 5, 7]

// Quando a única sentença em uma arrow function é um return, podemos resumir ainda mais
elementos.map(element => element.length); // [10, 5, 5, 7]



// Daqui pra baixo começa ficar divertido :)

// Neste caso, como só precisamos da propriedade length, podemos usar o parâmetro de destruição (destructing parameter).
// Note que a string "length" corresponde a propriedade que queremos obter enquanto que a propriedade não-especial
// `lengthFooBarX` é só um nome aleatório de uma variável que pode ser mudado para qualquer nome válido que você quiser.
elementos.map(({ length: lengthFooBarX }) => lengthFooBarX); // [10, 5, 5, 7]

// Esta atribuição de parâmetro de destruição (destructing parameter) pode ser escrita como visto abaixo. Entretanto, note que
// não há um "length" específico para selecionar qual propriedade nós queremos obter. Ao invés disso, o nome literal
// da própria variável `length` é usado como a propriedade que queremos recuperar do objeto.
elementos.map(({ length }) => length); // [10, 5, 5, 7]
