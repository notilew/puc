// Exemplo extraído e adaptado de MDN

// Usando strings normais
console.log("primeira linha do texto\n\
segunda linha do texto 2");
// "primeira linha do texto"
// "segunda linha do texto"

// Usando template literals (qualquer quebra de linha é parte do template literal)
console.log(`primeira linha do texto
segunda linha do texto 2`);
// "primeira linha do texto"
// "segunda linha do texto"