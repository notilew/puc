// Exemplo extraído e adaptado de MDN
function singularAutoPlural(singular, plural = singular+"s") {
  return [singular, plural ]; 
}

//["Test","Tests"]
singularAutoPlural("Test");

//["Fox", "Foxes"]
singularAutoPlural("Fox", "Foxes");