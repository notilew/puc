// Exemplo extraído e adaptado de MDN
var mySet = new Set();

mySet.add(1);
mySet.add(5);
mySet.add("texto");
var o = {a: 1, b: 2};
mySet.add(o);

mySet.add({a: 1, b: 2}); // o está referenciando outro objeto

mySet.has(1); // true
mySet.has(3); // false, 3 não foi adicionado ao set (Conjunto)
mySet.has(5);              // true
mySet.has(Math.sqrt(25));  // true
mySet.has("Texto".toLowerCase()); // true
mySet.has(o); // true

mySet.size; // 3

mySet.delete(5); // remove 5 do set
mySet.has(5);    // false, 5 já foi removido

mySet.size; // 2, nós simplesmente removemos um valor
