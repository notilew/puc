/**
 * Classe Album baseada em "function declaration"
 */
function Album(name) {
    this.id = undefined;
    this.name = name;
    this.photos = new Array();

    this.getName = function() {
        return this.name;
    };

    this.getPhotos = function() {
        return this.photos;
    };
    
    this.addPhoto = function(url) {
        this.photos.push(url);
    };
}

// Criando uma nova instância de Album
const albumModel = new Album('Fotos da viagem de final de ano');

// Definindo valores de um atributo
albumModel.addPhoto('http://lorempixel.com/400/200/sports/1/');
albumModel.addPhoto('http://lorempixel.com/400/200/sports/2/');

// Acessando propriedades
console.log(albumModel.getName()); // Output: Fotos da viagem de final de ano
console.log(albumModel.getPhotos().length); // Output: 2
