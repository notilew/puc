// Exemplo extraído e adaptado de MDN

var nome = 'Pedro';
var idade = 28;

function myTag(strings, expressaoNome, expressaoIdade) {
  let str0 = strings[0]; // "A pessoa "
  let str1 = strings[1]; // " é "
  let str2 = strings[2]; // "."

  if (expressaoIdade > 99){
    expressaoIdade = 'centenária';
  } else {
    expressaoIdade = 'jovem';
  }

  // Pode-se usar novamente uma template literal para montar o retorno
  return `${str0}${expressaoNome}${str1}${expressaoIdade}${str2}`;
}

var output = myTag`Aquela pessoa chamada ${ nome } é ${ idade }.`;

console.log(output); // A pessoa Pedro é jovem.