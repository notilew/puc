// Exemplo extraído e adaptado de MDN
// Sintaxe básica
`string text`

// Multi-linha
`string text line 1
 string text line 2`

// Interpolação de string
`string text ${expression} string text`

// Tagged template strings
tag `string text ${expression} string text`
