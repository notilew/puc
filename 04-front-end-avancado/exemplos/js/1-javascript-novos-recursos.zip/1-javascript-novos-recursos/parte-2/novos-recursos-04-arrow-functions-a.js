// Exemplo extraído e adaptado de MDN
// Sintaxe básica
(param1, param2, …, paramN) => { statements } 
(param1, param2, …, paramN) => expression // igual a: => { return expression; }

// Parênteses são opcionais quando existe apenas um parâmetro
(singleParam) => { statements }
singleParam => { statements }

// Funções sem parâmetro devem ser escritas com um par de parênteses vazios
() => { statements }
