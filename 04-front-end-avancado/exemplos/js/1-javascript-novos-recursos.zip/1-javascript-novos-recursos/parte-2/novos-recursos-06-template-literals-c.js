// Exemplo extraído e adaptado de MDN

// Encapsulando expressões dentro de strings com concatenação normal
var a = 5;
var b = 10;
console.log("A soma de " + a + " + " + b + " é: " + (a + b) + ".");
// "A soma de 5 + 10 é: 15."

// Interpolação de expressões
console.log(`A soma de ${a} + ${b} é: ${(a + b)}.`);
// "A soma de 5 + 10 é: 15."