// Exemplo extraído e adaptado de MDN
function multiplicaV1(a, b) {
  b = typeof b !== "undefined" ? b : 1;

  return a * b;
}

multiplicaV1(5, 2); // 10
multiplicaV1(5, 1); // 5 
multiplicaV1(5);    // 5

function multiplicaV2(a, b = 1) {
  return a * b;
}

multiplicaV2(5, 2); // 10
multiplicaV2(5, 1); // 5 
multiplicaV2(5);    // 5