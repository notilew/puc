// Exemplo extraído e adaptado de MDN

// Usando arguments
function multiplica(multiplicador) {
  let elementos = Array.from(arguments).slice(1);
  return elementos.map(function (elemento) {
    return multiplicador * elemento;
  });
}
    
var arr = multiplica(2, 1, 2, 3); 
console.log(arr); // [2, 4, 6]


// Usando parametros rest
function multiplica(multiplicador, ...elementos) {
  return elementos.map(function (elemento) {
    return multiplicador * elemento;
  });
}
  
var arr = multiplica(2, 1, 2, 3); 
console.log(arr); // [2, 4, 6]